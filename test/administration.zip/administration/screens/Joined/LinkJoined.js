import { StyleSheet, Text, View, useWindowDimensions } from 'react-native'
import React, { useState } from 'react'
import { appStyle } from '../../theme/appStyle'
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import OrderHistoryLink from './OrderHistoryLink'
import SynchronousStoreLink from './SynchronousStoreLink'
import { TabView, SceneMap } from 'react-native-tab-view';
import { COLOR } from '../../theme/color';

const renderScene = SceneMap({
  first: OrderHistoryLink,
  second: SynchronousStoreLink,
});
const LinkJoined = () => {
  const layout = useWindowDimensions();

  const [index, setIndex] = React.useState(0);
  const [routes] = React.useState([
    { key: 'first', title: 'Order history' },
    { key: 'second', title: 'Synchronous store list' },
  ]);


  return (
    <View style={appStyle.boxInfo}>
      <TabView
      lazy={true}
        navigationState={{ index, routes }}
        renderScene={renderScene}
        onIndexChange={setIndex}
        style={appStyle.TabView}
        indicatorStyle={{ backgroundColor: 'red' }}
        initialLayout={{ width: layout.width }}
        activeColor={COLOR.active}
      />
    </View>

  )
}
{/* <Tab.Navigator  style={appStyle.boxInfo}>
<Tab.Screen name="Home" component={OrderHistoryLink} />
<Tab.Screen name="Profile" component={SynchronousStoreLink} />
</Tab.Navigator> */}
export default LinkJoined

const styles = StyleSheet.create({})