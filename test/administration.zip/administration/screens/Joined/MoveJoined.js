import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { appStyle } from '../../theme/appStyle'

const MoveJoined = () => {
  return (
    <View style={appStyle.boxInfo}>
      <Text>MoveJoined</Text>
    </View>
  )
}

export default MoveJoined

const styles = StyleSheet.create({})