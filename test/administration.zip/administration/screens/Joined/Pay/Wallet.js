import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Wallet = () => {
  return (
    <View>
      <Text>Wallet</Text>
    </View>
  )
}

export default Wallet

const styles = StyleSheet.create({})