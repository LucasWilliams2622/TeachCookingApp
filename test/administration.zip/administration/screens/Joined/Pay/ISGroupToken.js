import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ISGroupToken = () => {
  return (
    <View>
      <Text>ISGroupToken</Text>
    </View>
  )
}

export default ISGroupToken

const styles = StyleSheet.create({})