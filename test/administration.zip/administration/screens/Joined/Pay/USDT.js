import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const USDT = () => {
  return (
    <View>
      <Text>USDT</Text>
    </View>
  )
}

export default USDT

const styles = StyleSheet.create({})