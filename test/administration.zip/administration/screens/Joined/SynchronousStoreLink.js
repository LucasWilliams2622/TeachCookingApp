import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const SynchronousStoreLink = () => {
  return (
    <View>
      <Text>SynchronousStoreLink</Text>
    </View>
  )
}

export default SynchronousStoreLink

const styles = StyleSheet.create({})