import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const OrderHistoryLink = () => {
  return (
    <View>
      <Text>OrderHistoryLink</Text>
    </View>
  )
}

export default OrderHistoryLink

const styles = StyleSheet.create({})