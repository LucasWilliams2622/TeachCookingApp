import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { appStyle } from '../../theme/appStyle'

const PayJoined = () => {
  return (
    <View style={appStyle.boxInfo}>
      <Text>PayJoined</Text>
    </View>
  )
}

export default PayJoined

const styles = StyleSheet.create({})