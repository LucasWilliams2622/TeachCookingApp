import HistoryMatching from './HistoryMatching'
import ListContent from './PostList'
import ProcessedMatching from './ProcessedMatching'

const vars = {
    HistoryMatching: HistoryMatching,
    PostList: PostList,
    ProcessedMatching: ProcessedMatching,
}
export default vars;