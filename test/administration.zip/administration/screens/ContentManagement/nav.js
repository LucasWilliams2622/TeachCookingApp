import AddContent from './AddContent'
import ListContent from './ListContent'
import DetailContent from './DetailContent'

const vars = {
    AddContent: AddContent,
    ListContent: ListContent,
    DetailContent: DetailContent,
}
export default vars;