import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Dividend = () => {
  return (
    <View>
      <Text>Dividend</Text>
    </View>
  )
}

export default Dividend

const styles = StyleSheet.create({})