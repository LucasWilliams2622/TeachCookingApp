import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ComplaintHistory = () => {
  return (
    <View>
      <Text>ComplaintHistory</Text>
    </View>
  )
}

export default ComplaintHistory

const styles = StyleSheet.create({})