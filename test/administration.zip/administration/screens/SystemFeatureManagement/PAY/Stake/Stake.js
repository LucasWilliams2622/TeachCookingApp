import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Stake = () => {
  return (
    <View>
      <Text>Stake</Text>
    </View>
  )
}

export default Stake

const styles = StyleSheet.create({})