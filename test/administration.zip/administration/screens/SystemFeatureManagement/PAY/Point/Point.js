import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Point = () => {
    return (
        <View>
            <Text>Point</Text>
        </View>
    )
}

export default Point

const styles = StyleSheet.create({})