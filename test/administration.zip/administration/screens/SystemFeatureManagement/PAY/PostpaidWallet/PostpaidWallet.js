import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const PostpaidWallet = () => {
  return (
    <View>
      <Text>PostpaidWallet</Text>
    </View>
  )
}

export default PostpaidWallet

const styles = StyleSheet.create({})