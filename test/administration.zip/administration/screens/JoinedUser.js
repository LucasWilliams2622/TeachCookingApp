import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const JoinedUser = () => {
  return (
    <View>
      <Text>JoinedUser</Text>
    </View>
  )
}

export default JoinedUser

const styles = StyleSheet.create({})