import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Administration = () => {
  return (
    <View>
      <Text>Administration</Text>
    </View>
  )
}

export default Administration

const styles = StyleSheet.create({})