import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const UserManagement = () => {
  return (
    <View>
      <Text>UserManagement</Text>
    </View>
  )
}

export default UserManagement

const styles = StyleSheet.create({})