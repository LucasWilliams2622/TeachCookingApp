import { ScrollView, StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Chat = () => {
  return (
    <ScrollView>

    </ScrollView>
  )
}

export default Chat

const styles = StyleSheet.create({})